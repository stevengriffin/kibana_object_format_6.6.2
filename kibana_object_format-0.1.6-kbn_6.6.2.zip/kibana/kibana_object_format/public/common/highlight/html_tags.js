// These are the html tags that will replace the highlight tags.
export const htmlTags = {
  pre: '<mark>',
  post: '</mark>'
};
